package com.yanader.ss_2024_c1_e1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ss2024C1E1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
